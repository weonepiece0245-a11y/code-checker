def f(:
    pass
